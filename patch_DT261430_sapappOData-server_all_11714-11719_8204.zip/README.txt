PATCH FOR APAR         : DT261430
PATCH NAME             : patch_DT261430_sapappOData-server_all_11714-11719_8204
APAR SUMMARY           : Query option support for SAP OData connector
ENGINEERING TEAM       : IIS - Conn SAP
COMPONENT              : InfoSphere Information Server Pack for SAP Applications
TIERS                  : Engine
OPERATING SYSTEMS      : Unix
SUITE VERSION*         : 11.7.1.4+
COMPONENT VERSION      : 8.2.0.4
UNINSTALL**            : Supported
PRE-INSTALL STEPS      : Required, see dedicated section below
SPECIFIC INSTALL STEPS : None
POST-INSTALL STEPS     : None
RECOMPILE JOBS         : None required

  * This patch requires that IBM Information Server suite be
    installed at the level shown, or at a later fixpack level.

 ** If the patch can be uninstalled (see above) and you need to uninstall it,
    see the patch installation instructions for information on uninstalling.
	
PRE-INSTALL STEPS
================= 
1. Close the DataStage Designer Client and check through Task Manager that no instance of DSDesign.exe are running.
    
INSTALLATION INSTRUCTIONS:
==========================
  Generic patch installation instructions are available with this download and are also available separately here: 
 https://www.ibm.com/support/pages/updating-ibm-infosphere-information-server-version-117-and-installing-additional-products
    
  NOTE: This patch is only applicable to English installations. For other languages, please contact Support.

PROBLEM DETAILS:
================
  Query option support for OData connector for IIS11715

RESOLUTION:
===========
  Code fix:  Support for filter,select,skiptoken and orderby Query Options for SAP OData V2 
PATCHED FILES: 
==============
  This patch modifies the following files, shown from the root of the IBM Information Server installation:
    Server/DSComponents/bin/sapodata_Package.jar
 
FIX CONTENT:
============
 This is a cumulative patch, it includes all fixes available for the component on the build date:
  DT261430 - Query option support for SAP OData connector
  DT209485 - SAP OData connector runtime failure with IIS 11.7.1.4 SP1.

SUPPORT POLICY STATEMENT FOR FIX PACKS AND PATCHES:
===================================================
  The following document describes the role and purpose of IBM InfoSphere Information Server fix packs and patches.
  http://www-01.ibm.com/support/docview.wss?uid=swg27037015


